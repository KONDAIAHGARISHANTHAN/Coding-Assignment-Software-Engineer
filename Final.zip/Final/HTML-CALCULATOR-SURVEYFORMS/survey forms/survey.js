// Get form and popup elements
const surveyForm = document.getElementById('survey-form');
const popup = document.getElementById('popup');
const closePopup = document.getElementById('close-popup');
const popupResults = document.getElementById('popup-results');

// Function to display the popup with selected values
function showPopup() {
    const formData = new FormData(surveyForm);
    let popupContent = '<ul>';
    for (const [key, value] of formData.entries()) {
        popupContent += `<li><strong>${key}:</strong> ${value}</li>`;
    }
    popupContent += '</ul>';
    popupResults.innerHTML = popupContent;
    popup.style.display = 'block';
}

// Event listener for form submission
surveyForm.addEventListener('submit', function (e) {
    e.preventDefault();
    showPopup();
    surveyForm.reset();
});

// Event listener for closing the popup
closePopup.addEventListener('click', function () {
    popup.style.display = 'none';
});
