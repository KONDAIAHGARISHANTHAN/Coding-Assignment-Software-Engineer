let result = '';

function appendToResult(value) {
    result += value;
    document.getElementById('result').value = result;
}

function clearResult() {
    result = '';
    document.getElementById('result').value = result;
}

function calculate() {
    if (result !== '') {
        try {
            result = eval(result);
            document.getElementById('result').value = result;
        } catch (error) {
            document.getElementById('result').value = 'Error';
        }
    }
}

// Handle the BODMAS/BIDMAS operations
function operate(operator) {
    switch (operator) {
        case '+':
        case '-':
        case '*':
        case '/':
            // Ensure there are no consecutive operators
            if (/[\+\-\*\/]$/.test(result)) {
                return;
            }
            break;
        default:
            break;
    }
    
    appendToResult(operator);
}
