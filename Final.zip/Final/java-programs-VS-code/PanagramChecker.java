import java.util.HashSet;
import java.util.Set;

public class PangramChecker {
    public static void main(String[] args) {
        String input = "The quick brown fox jumps over the lazy dog";

        boolean isPangram = isPangram(input);

        if (isPangram) {
            System.out.println("The input is a pangram.");
        } else {
            System.out.println("The input is not a pangram.");
        }
    }

    public static boolean isPangram(String input) {
        // Create a set to store unique lowercase letters
        Set<Character> uniqueLetters = new HashSet<>();

        // Convert the input to lowercase and iterate through each character
        for (char c : input.toLowerCase().toCharArray()) {
            if (Character.isLetter(c)) {
                uniqueLetters.add(c);
            }
        }

        // Check if there are 26 unique letters (A to Z)
        return uniqueLetters.size() == 26;
    }
}
