import java.util.*;

public class shuffle {
    public static void main(String[] args) {
        // Create a linked list object
        LinkedList<Integer> list = new LinkedList<Integer>();

        // Add values to the list
        list.add(45);
        list.add(20);
        list.add(55);
        list.add(90);
        list.add(15);

        System.out.println("List before Shuffle = " + list);

        // Shuffle the list using Random()
        Collections.shuffle(list, new Random());
        System.out.println("Shuffled List with Random() = " + list);

        // Shuffle the list using Random(3)
        Collections.shuffle(list, new Random(3));
        System.out.println("Shuffled List with Random(3) = " + list);
    }
}
